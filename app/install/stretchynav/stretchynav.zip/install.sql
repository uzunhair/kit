INSERT INTO `{#}widgets` (`controller`, `name`, `title`, `author`, `url`, `version`) VALUES
(NULL, 'stretchynav', 'StretchyNav', 'Atid', 'http://kitdeveloper.ru', '2.6');

