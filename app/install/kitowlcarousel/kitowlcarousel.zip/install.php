<?php
function install_package(){

        return true;

}
?>