INSERT INTO `{#}widgets` (`controller`, `name`, `title`, `author`, `url`, `version`) VALUES
('kitdeveloper', 'kitcarousel', 'Kit Carousel', 'Atid', 'http://kitdeveloper.ru', '2.6.1');

